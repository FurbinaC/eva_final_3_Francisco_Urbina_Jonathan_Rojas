CREATE DATABASE IF NOT EXISTS contador_final;

USE contador_final;

CREATE TABLE log (
    id int auto_increment primary key,
    hora VARCHAR(50) NOT NULL,
    actividad VARCHAR(100) NOT NULL,
    estado VARCHAR(50) NOT NULL,
    imagen TEXT
);

INSERT INTO log VALUES (null, "9:48", "creacion estructura de contenedor docker", "completado", "lol");
INSERT INTO log VALUES (null, "9:50", "estructura docker-compose", "completado", "lol");
INSERT INTO log VALUES (null, "9:55", "estructura Dockerfile", "completado", "lol");
INSERT INTO log VALUES (null, "10:10", "creacion estructura python", "completado", "lol");
INSERT INTO log VALUES (null, "10:15", "creacion requirements.txt", "completado", "lol");
INSERT INTO log VALUES (null, "10:30", "levantar contenedor", "completado", "lol");
INSERT INTO log VALUES (null, "10:40", "vista pagina con base de datos y la tabla", "completado", "lol");
